// miniKanren FPGA Test - John 3:16 ☧
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <fpga_pci.h>
#include <fpga_mgmt.h>

#define SLOT_ID 0

int main() {
    int rc;
    pci_bar_handle_t pci_bar_handle = PCI_BAR_HANDLE_INIT;
    
    printf("=== miniKanren F2 FPGA Test ===\n");
    printf("Soli Deo Gloria - John 3:16 ☧\n\n");
    
    // Initialize FPGA management library
    rc = fpga_mgmt_init();
    if (rc) {
        printf("ERROR: fpga_mgmt_init failed: %d\n", rc);
        return 1;
    }
    
    // Attach to BAR0 (OCL interface)
    rc = fpga_pci_attach(SLOT_ID, FPGA_APP_PF, APP_PF_BAR0, 0, &pci_bar_handle);
    if (rc) {
        printf("ERROR: fpga_pci_attach failed: %d\n", rc);
        return 1;
    }
    printf("Successfully attached to FPGA slot %d, BAR0\n", SLOT_ID);
    
    // Read some registers
    uint32_t value;
    printf("\nReading OCL registers:\n");
    
    for (int addr = 0; addr < 0x40; addr += 4) {
        rc = fpga_pci_peek(pci_bar_handle, addr, &value);
        if (rc) {
            printf("  0x%04x: READ ERROR (%d)\n", addr, rc);
        } else {
            printf("  0x%04x: 0x%08x\n", addr, value);
        }
    }
    
    // Try writing and reading back
    printf("\nWrite/Read test at 0x500:\n");
    uint32_t test_val = 0xDEADBEEF;
    rc = fpga_pci_poke(pci_bar_handle, 0x500, test_val);
    if (rc) {
        printf("  Write 0x%08x: ERROR (%d)\n", test_val, rc);
    } else {
        printf("  Write 0x%08x: OK\n", test_val);
    }
    
    rc = fpga_pci_peek(pci_bar_handle, 0x500, &value);
    if (rc) {
        printf("  Read back: ERROR (%d)\n", rc);
    } else {
        printf("  Read back: 0x%08x %s\n", value, (value == test_val) ? "MATCH!" : "MISMATCH");
    }
    
    // Cleanup
    fpga_pci_detach(pci_bar_handle);
    printf("\nTest complete.\n");
    
    return 0;
}
