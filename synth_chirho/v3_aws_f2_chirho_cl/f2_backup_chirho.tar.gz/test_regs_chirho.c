// Test miniKanren register map - John 3:16 ☧
#include <stdio.h>
#include <stdint.h>
#include <fpga_pci.h>
#include <fpga_mgmt.h>

#define SLOT_ID 0

// Register map from cl_minikanren_chirho.sv
#define REG_VERSION  0x000
#define REG_CONTROL  0x004
#define REG_STATUS   0x008
#define REG_CMD_LO   0x010
#define REG_CMD_MID  0x014
#define REG_CMD_HI   0x018
#define REG_RESP_0   0x020

int main() {
    int rc;
    pci_bar_handle_t bar;
    uint32_t val;
    
    printf("=== miniKanren Register Test ===\n");
    printf("Soli Deo Gloria - John 3:16 ☧\n\n");
    
    fpga_mgmt_init();
    rc = fpga_pci_attach(SLOT_ID, FPGA_APP_PF, APP_PF_BAR0, 0, &bar);
    if (rc) { printf("Attach failed\n"); return 1; }
    
    printf("Register Map Test:\n");
    
    // VERSION register
    rc = fpga_pci_peek(bar, REG_VERSION, &val);
    printf("  VERSION  (0x%03x): 0x%08x %s\n", REG_VERSION, val,
           (val == 0xf2020001) ? "(F2 Shell)" : "");
    
    // CONTROL register - read
    rc = fpga_pci_peek(bar, REG_CONTROL, &val);
    printf("  CONTROL  (0x%03x): 0x%08x\n", REG_CONTROL, val);
    
    // STATUS register
    rc = fpga_pci_peek(bar, REG_STATUS, &val);
    printf("  STATUS   (0x%03x): 0x%08x", REG_STATUS, val);
    if (val & 0x04) printf(" [HBM_READY]");
    if (val & 0x02) printf(" [VALID]");
    if (val & 0x01) printf(" [DONE]");
    printf("\n");
    
    // Try writing to CONTROL and reading back
    printf("\n=== Write/Read Test ===\n");
    printf("Writing 0x05 to CONTROL (enable + hbm_mode)...\n");
    rc = fpga_pci_poke(bar, REG_CONTROL, 0x05);
    printf("  Write result: %s\n", rc ? "FAIL" : "OK");
    
    rc = fpga_pci_peek(bar, REG_CONTROL, &val);
    printf("  Read back: 0x%08x %s\n", val, (val == 0x05) ? "MATCH!" : "");
    
    // Read STATUS again
    rc = fpga_pci_peek(bar, REG_STATUS, &val);
    printf("  STATUS after enable: 0x%08x", val);
    if (val & 0x04) printf(" [HBM_READY]");
    printf("\n");
    
    // Clear enable
    fpga_pci_poke(bar, REG_CONTROL, 0x00);
    
    // Test CMD registers
    printf("\n=== CMD Register Test ===\n");
    fpga_pci_poke(bar, REG_CMD_LO, 0x12345678);
    fpga_pci_poke(bar, REG_CMD_MID, 0xABCDEF00);
    fpga_pci_poke(bar, REG_CMD_HI, 0x0000003F);
    
    fpga_pci_peek(bar, REG_CMD_LO, &val);
    printf("  CMD_LO  (0x%03x): 0x%08x %s\n", REG_CMD_LO, val,
           (val == 0x12345678) ? "MATCH!" : "");
    fpga_pci_peek(bar, REG_CMD_MID, &val);
    printf("  CMD_MID (0x%03x): 0x%08x %s\n", REG_CMD_MID, val,
           (val == 0xABCDEF00) ? "MATCH!" : "");
    fpga_pci_peek(bar, REG_CMD_HI, &val);
    printf("  CMD_HI  (0x%03x): 0x%08x %s\n", REG_CMD_HI, val,
           ((val & 0x3F) == 0x3F) ? "MATCH!" : "");
    
    // Read RESP registers
    printf("\n=== RESP Registers ===\n");
    for (int i = 0; i < 4; i++) {
        fpga_pci_peek(bar, REG_RESP_0 + i*4, &val);
        printf("  RESP[%d] (0x%03x): 0x%08x\n", i, REG_RESP_0 + i*4, val);
    }
    
    printf("\nTest complete.\n");
    return 0;
}
