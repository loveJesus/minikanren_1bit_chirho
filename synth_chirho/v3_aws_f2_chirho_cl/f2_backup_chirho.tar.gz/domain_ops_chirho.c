// Domain operation benchmark - John 3:16 ☧
#include <stdio.h>
#include <stdint.h>
#include <time.h>
#include <fpga_pci.h>
#include <fpga_mgmt.h>

#define SLOT_ID 0
#define REG_CONTROL  0x004
#define REG_STATUS   0x008
#define REG_CMD_LO   0x010
#define REG_CMD_MID  0x014
#define REG_RESP_0   0x020

static inline uint64_t get_time_ns() {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000000000ULL + ts.tv_nsec;
}

int main() {
    pci_bar_handle_t bar0;
    fpga_mgmt_init();
    fpga_pci_attach(SLOT_ID, FPGA_APP_PF, APP_PF_BAR0, 0, &bar0);
    
    printf("=== Domain Operation Comparison ===\n\n");
    
    const char *op_names[] = {"INTERSECT", "UNION", "COMPLEMENT", "IS_GROUND"};
    int iterations = 10000;
    
    for (int op = 0; op < 4; op++) {
        uint64_t start = get_time_ns();
        
        for (int i = 0; i < iterations; i++) {
            uint32_t cmd = op | (0 << 4) | (1 << 20);  // op, var0, var1
            fpga_pci_poke(bar0, REG_CMD_LO, cmd);
            fpga_pci_poke(bar0, REG_CMD_MID, 0x00010000);  // batch=1
            fpga_pci_poke(bar0, REG_CONTROL, 0x05);
            
            uint32_t status;
            fpga_pci_peek(bar0, REG_STATUS, &status);
            fpga_pci_poke(bar0, REG_CONTROL, 0);
        }
        
        uint64_t end = get_time_ns();
        double latency_ns = (double)(end - start) / iterations;
        double throughput = 1e9 / latency_ns / 1e6;
        
        printf("%-12s: %.1f ns, %.3f M ops/sec\n", op_names[op], latency_ns, throughput);
    }
    
    // Test result reading
    printf("\n=== Result Register Access ===\n");
    
    // Do an operation
    fpga_pci_poke(bar0, REG_CMD_LO, 0x10);  // INTERSECT var0, var1
    fpga_pci_poke(bar0, REG_CMD_MID, 0x00010000);
    fpga_pci_poke(bar0, REG_CONTROL, 0x05);
    
    uint32_t status;
    fpga_pci_peek(bar0, REG_STATUS, &status);
    printf("STATUS: 0x%08x\n", status);
    
    for (int i = 0; i < 8; i++) {
        uint32_t resp;
        fpga_pci_peek(bar0, REG_RESP_0 + i*4, &resp);
        printf("RESP[%d]: 0x%08x\n", i, resp);
    }
    
    fpga_pci_poke(bar0, REG_CONTROL, 0);
    fpga_pci_detach(bar0);
    return 0;
}
