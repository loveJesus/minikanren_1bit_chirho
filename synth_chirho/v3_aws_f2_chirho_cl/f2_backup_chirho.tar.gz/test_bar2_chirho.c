// Test BAR2 (SDA interface) - John 3:16 ☧
#include <stdio.h>
#include <stdint.h>
#include <fpga_pci.h>
#include <fpga_mgmt.h>

#define SLOT_ID 0

int main() {
    int rc;
    pci_bar_handle_t bar0, bar2, bar4;
    
    printf("=== Testing All BARs ===\n");
    
    fpga_mgmt_init();
    
    // BAR0 - OCL
    rc = fpga_pci_attach(SLOT_ID, FPGA_APP_PF, APP_PF_BAR0, 0, &bar0);
    printf("BAR0 (OCL): %s\n", rc ? "FAILED" : "OK");
    
    // BAR2 - SDA (optional, might fail)
    rc = fpga_pci_attach(SLOT_ID, FPGA_APP_PF, APP_PF_BAR2, 0, &bar2);
    printf("BAR2 (SDA): %s\n", rc ? "FAILED" : "OK");
    
    // BAR4 - PCIS/HBM
    rc = fpga_pci_attach(SLOT_ID, FPGA_APP_PF, APP_PF_BAR4, 0, &bar4);
    printf("BAR4 (HBM): %s\n", rc ? "FAILED" : "OK");
    
    uint32_t val;
    
    // Read from BAR2 if available
    if (bar2 != PCI_BAR_HANDLE_INIT) {
        printf("\nBAR2 registers:\n");
        for (int a = 0; a < 0x40; a += 4) {
            rc = fpga_pci_peek(bar2, a, &val);
            if (rc == 0) printf("  0x%04x: 0x%08x\n", a, val);
        }
    }
    
    // Test HBM access via BAR4
    if (bar4 != PCI_BAR_HANDLE_INIT) {
        printf("\nBAR4 (HBM) first 64 bytes:\n");
        for (int a = 0; a < 0x40; a += 4) {
            rc = fpga_pci_peek(bar4, a, &val);
            if (rc == 0) printf("  0x%04x: 0x%08x\n", a, val);
            else printf("  0x%04x: ERROR\n", a);
        }
        
        // Try write/read to HBM
        printf("\nHBM Write/Read test:\n");
        uint32_t test = 0x12345678;
        rc = fpga_pci_poke(bar4, 0x1000, test);
        printf("  Write 0x%08x to 0x1000: %s\n", test, rc ? "FAIL" : "OK");
        rc = fpga_pci_peek(bar4, 0x1000, &val);
        printf("  Read back: 0x%08x %s\n", val, val == test ? "MATCH!" : "");
    }
    
    printf("\nDone.\n");
    return 0;
}
