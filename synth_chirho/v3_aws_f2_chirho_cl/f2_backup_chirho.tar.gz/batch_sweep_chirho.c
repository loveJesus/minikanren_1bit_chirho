// Batch size sweep benchmark - John 3:16 ☧
#include <stdio.h>
#include <stdint.h>
#include <time.h>
#include <fpga_pci.h>
#include <fpga_mgmt.h>

#define SLOT_ID 0
#define REG_CONTROL  0x004
#define REG_STATUS   0x008
#define REG_CMD_LO   0x010
#define REG_CMD_MID  0x014

static inline uint64_t get_time_ns() {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000000000ULL + ts.tv_nsec;
}

int main() {
    pci_bar_handle_t bar0;
    fpga_mgmt_init();
    fpga_pci_attach(SLOT_ID, FPGA_APP_PF, APP_PF_BAR0, 0, &bar0);
    
    printf("=== Batch Size Sweep ===\n");
    printf("BatchSize,TotalTime_us,PerPair_ns,Throughput_Mops\n");
    
    int batch_sizes[] = {1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096};
    int num_sizes = sizeof(batch_sizes) / sizeof(batch_sizes[0]);
    
    for (int s = 0; s < num_sizes; s++) {
        int batch_size = batch_sizes[s];
        int iterations = 1000;
        
        uint64_t start = get_time_ns();
        
        for (int iter = 0; iter < iterations; iter++) {
            fpga_pci_poke(bar0, REG_CMD_LO, 0x10);  // var0, var1, INTERSECT
            fpga_pci_poke(bar0, REG_CMD_MID, batch_size << 4);
            fpga_pci_poke(bar0, REG_CONTROL, 0x05);  // enable + hbm_mode
            
            uint32_t status;
            int timeout = 100000;
            do {
                fpga_pci_peek(bar0, REG_STATUS, &status);
                timeout--;
            } while (!(status & 0x01) && timeout > 0);
            
            fpga_pci_poke(bar0, REG_CONTROL, 0);
        }
        
        uint64_t end = get_time_ns();
        
        double total_time_us = (double)(end - start) / 1000.0 / iterations;
        double per_pair_ns = (total_time_us * 1000.0) / batch_size;
        double throughput = (double)batch_size / (total_time_us / 1e6) / 1e6;
        
        printf("%d,%.3f,%.1f,%.3f\n", batch_size, total_time_us, per_pair_ns, throughput);
    }
    
    fpga_pci_detach(bar0);
    return 0;
}
