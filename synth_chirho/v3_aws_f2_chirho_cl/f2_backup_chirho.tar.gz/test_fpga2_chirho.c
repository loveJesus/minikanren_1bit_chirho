// Extended miniKanren FPGA Test - John 3:16 ☧
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <fpga_pci.h>
#include <fpga_mgmt.h>

#define SLOT_ID 0

int main() {
    int rc;
    pci_bar_handle_t pci_bar_handle = PCI_BAR_HANDLE_INIT;
    
    printf("=== miniKanren F2 FPGA Extended Test ===\n");
    printf("Soli Deo Gloria - John 3:16 ☧\n\n");
    
    fpga_mgmt_init();
    rc = fpga_pci_attach(SLOT_ID, FPGA_APP_PF, APP_PF_BAR0, 0, &pci_bar_handle);
    if (rc) { printf("Attach failed: %d\n", rc); return 1; }
    
    uint32_t value;
    
    // Scan more addresses to find miniKanren engine
    printf("Scanning OCL address space:\n");
    int interesting[32];
    int count = 0;
    
    for (uint64_t addr = 0; addr < 0x10000; addr += 0x100) {
        rc = fpga_pci_peek(pci_bar_handle, addr, &value);
        if (rc == 0 && value != 0x00000000 && value != 0xffffffff) {
            printf("  0x%05lx: 0x%08x", addr, value);
            if (value == 0xf2020001) printf(" (F2 Shell ID)");
            if (value == 0xdeadbeef) printf(" (Placeholder)");
            if ((value & 0xFFFF0000) == 0xF0160000) printf(" (John 3:16!)");
            printf("\n");
            if (count < 32) interesting[count++] = addr;
        }
    }
    
    // Read 16 words around each interesting address
    printf("\n=== Detailed register dump around interesting addresses ===\n");
    for (int i = 0; i < count && i < 4; i++) {
        uint64_t base = interesting[i] & ~0x3F;
        printf("\nAround 0x%x:\n", interesting[i]);
        for (uint64_t off = 0; off < 0x40; off += 4) {
            rc = fpga_pci_peek(pci_bar_handle, base + off, &value);
            if (rc == 0) printf("  0x%05lx: 0x%08x\n", base + off, value);
        }
    }
    
    fpga_pci_detach(pci_bar_handle);
    printf("\nScan complete.\n");
    return 0;
}
